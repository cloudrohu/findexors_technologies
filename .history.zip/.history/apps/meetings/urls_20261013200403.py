from django.urls import path
from . import views


app_name = "meetings"


urlpatterns = [

    path(
        "property/",
        views.property_meetings,
        name="property_meetings"
    ),

    path(
        "dashboard/meeting/property/",
        views.property_meetings,
        name="property_meetings",
    ),

    path(
        "dashboard/meeting/<str:meeting_id>/edit/",
        views.edit_meeting,
        name="edit_meeting",
    ),

]