from django.urls import path
from . import views

from apps.properties.views import edit_meeting


urlpatterns = [

    path(
        "dashboard/meeting/property/",
        views.property_meetings,
        name="property_meetings",
    ),

    path(
        "dashboard/meeting/<str:meeting_id>/edit/",
        edit_meeting,
        name="edit_meeting",
    ),

]