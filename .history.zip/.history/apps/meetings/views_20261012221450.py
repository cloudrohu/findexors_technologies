from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render

from apps.properties.models import Meeting


def property_meetings(request):

    context = {
        "project_meeting_count": Meeting.objects.filter(
            type="Project"
        ).count(),

        "developer_meeting_count": Meeting.objects.filter(
            type="Developer"
        ).count(),

        "architect_meeting_count": Meeting.objects.filter(
            type="Architect"
        ).count(),

        "engineer_meeting_count": Meeting.objects.filter(
            type="Engineer"
        ).count(),
    }

    return render(
        request,
        "dashboard/meeting/property_meetings.html",
        context
    )