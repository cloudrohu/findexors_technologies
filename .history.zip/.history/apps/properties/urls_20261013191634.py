from django.urls import path
from . import views

from django.urls import path

from .views import (
    property_meetings,
    edit_developer,
    edit_meeting,
)

urlpatterns = [
    path('', views.index, name='properties'),

    path('residential/',views.residential_projects,name='residential_projects'),

    path('commercial/',views.commercial_projects,name='commercial_projects'),

    path('search/',views.search_projects,name='search_projects'),

    path('submit-enquiry/<int:id>/',views.submit_enquiry,name='submit_enquiry'),

    path('thank-you/',views.thank_you,name='thank_you'),

    path('api/search-suggestions/',views.search_suggestions,name='search_suggestions'),


    path(
        "dashboard/meeting/property/",
        property_meetings,
        name="property_meetings",
    ),

    path(
        "dashboard/meeting/developer/<str:developer_id>/edit/",
        edit_developer,
        name="edit_developer",
    ),

    path(
        "dashboard/meeting/<str:meeting_id>/edit/",
        edit_meeting,
        name="edit_meeting",
    ),

    path(
        'api/search-suggestions/',
        views.search_suggestions,
        name='search_suggestions'
    ),

    path(
        'search/',
        views.search_projects,
        name='search_projects'
    ),

    path('search/',views.search_projects,name='search_projects'),

    # Project Details
    path('<int:id>/<slug:slug>/',views.project_details,name='project_details'),
]