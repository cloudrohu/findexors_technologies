from django import forms

from .models import Developer, Meeting


# ============================================================
# DEVELOPER EDIT FORM
# ============================================================

class DeveloperEditForm(forms.ModelForm):

    class Meta:
        model = Developer

        fields = [
            "title",

            # Location
            "city",
            "locality",
            "area",
            "postal_code",
            "address",
            "google_map",

            # Contact
            "contact_person",
            "contact_no",
            "email",
            "web_site",

            # Description
            "keywords",
            "about_developer",
            "note",

            # Logo
            "logo",

            # Status
            "calling_status",
            "assigned_to",
            "featured_builder",
            "is_featured",
            "is_verified",
            "is_active",
        ]

        widgets = {

            "title": forms.TextInput(
                attrs={
                    "class": "fx-input",
                    "placeholder": "Developer name",
                }
            ),

            "city": forms.Select(
                attrs={
                    "class": "fx-input",
                }
            ),

            "locality": forms.Select(
                attrs={
                    "class": "fx-input",
                }
            ),

            "area": forms.Select(
                attrs={
                    "class": "fx-input",
                }
            ),

            "postal_code": forms.Select(
                attrs={
                    "class": "fx-input",
                }
            ),

            "address": forms.Textarea(
                attrs={
                    "class": "fx-input",
                    "rows": 3,
                    "placeholder": "Full address",
                }
            ),

            "google_map": forms.URLInput(
                attrs={
                    "class": "fx-input",
                    "placeholder": "Google Maps URL",
                }
            ),

            "contact_person": forms.TextInput(
                attrs={
                    "class": "fx-input",
                    "placeholder": "Contact person",
                }
            ),

            "contact_no": forms.TextInput(
                attrs={
                    "class": "fx-input",
                    "placeholder": "Contact number",
                    "maxlength": "10",
                }
            ),

            "email": forms.EmailInput(
                attrs={
                    "class": "fx-input",
                    "placeholder": "Email address",
                }
            ),

            "web_site": forms.URLInput(
                attrs={
                    "class": "fx-input",
                    "placeholder": "Website URL",
                }
            ),

            "keywords": forms.TextInput(
                attrs={
                    "class": "fx-input",
                    "placeholder": "Keywords",
                }
            ),

            "about_developer": forms.Textarea(
                attrs={
                    "class": "fx-input",
                    "rows": 5,
                    "placeholder": "About developer",
                }
            ),

            "note": forms.Textarea(
                attrs={
                    "class": "fx-input",
                    "rows": 4,
                    "placeholder": "Internal note",
                }
            ),

            "logo": forms.ClearableFileInput(
                attrs={
                    "class": "fx-input",
                }
            ),

            "calling_status": forms.Select(
                attrs={
                    "class": "fx-input",
                }
            ),

            "assigned_to": forms.Select(
                attrs={
                    "class": "fx-input",
                }
            ),

            "featured_builder": forms.CheckboxInput(
                attrs={
                    "class": "fx-checkbox",
                }
            ),

            "is_featured": forms.CheckboxInput(
                attrs={
                    "class": "fx-checkbox",
                }
            ),

            "is_verified": forms.CheckboxInput(
                attrs={
                    "class": "fx-checkbox",
                }
            ),

            "is_active": forms.CheckboxInput(
                attrs={
                    "class": "fx-checkbox",
                }
            ),
        }


# ============================================================
# MEETING EDIT FORM
# ============================================================

class MeetingEditForm(forms.ModelForm):

    class Meta:
        model = Meeting

        fields = [
            "status",
            "meeting_date",
            "assigned_to",
            "comment",
        ]

        widgets = {

            "status": forms.Select(
                attrs={
                    "class": "fx-input",
                }
            ),

            "meeting_date": forms.DateTimeInput(
                format="%Y-%m-%dT%H:%M",
                attrs={
                    "class": "fx-input",
                    "type": "datetime-local",
                }
            ),

            "assigned_to": forms.Select(
                attrs={
                    "class": "fx-input",
                }
            ),

            "comment": forms.Textarea(
                attrs={
                    "class": "fx-input",
                    "rows": 5,
                    "placeholder": "Meeting comment...",
                }
            ),
        }

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        self.fields["meeting_date"].input_formats = [
            "%Y-%m-%dT%H:%M",
        ]