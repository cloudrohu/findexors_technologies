from import_export import resources, fields

from apps.business.models import BusinessMeeting


class BusinessMeetingResource(resources.ModelResource):

    id = fields.Field(
        attribute="id",
        column_name="id",
    )

    class Meta:

        model = BusinessMeeting

        fields = (
            "id",
            "enquiry",
            "meeting_type",
            "meeting_date",
            "meeting_time",
            "meeting_location",
            "agenda",
            "outcome",
            "next_action",
            "status",
            "assigned_to",
            "is_active",
            "created_at",
            "updated_at",
        )

        import_id_fields = (
            "id",
        )