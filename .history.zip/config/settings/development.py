from .base import *

# ------------------------------------------------------------------------------
# DEVELOPMENT SETTINGS
# ------------------------------------------------------------------------------

DEBUG = True

ALLOWED_HOSTS = [
    "127.0.0.1",
    "localhost",
]

EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"

INTERNAL_IPS = [
    "127.0.0.1",
]